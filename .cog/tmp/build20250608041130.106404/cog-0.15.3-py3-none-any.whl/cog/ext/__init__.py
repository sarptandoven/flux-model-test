# This `cog/ext` directory is a [namespace
# directory](https://packaging.python.org/en/latest/guides/packaging-namespace-packages/)
# that intentionally does not contain any production code.
